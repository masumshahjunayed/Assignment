package com.Sheet;

public class P1Arr {

	public static void main(String[] args) {
		
		int array[] = {7, 13, 2, 10, 6};
		
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + ",");
		}
		
		System.out.println();
		
	}

}
