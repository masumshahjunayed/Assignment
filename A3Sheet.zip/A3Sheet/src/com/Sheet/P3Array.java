package com.Sheet;

public class P3Array {

	public static void main(String[] args) {
		
		int array[] = {7, 13, 2, 10, 6};
		
		for (int i = 0; i < array.length; i++) {
			if (array[i]<10) {
				System.out.print(array[i] + ",");
			}
		}
		
		System.out.println();

	}

}
