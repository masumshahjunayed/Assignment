package com.Sheet;

import java.util.Scanner;

public class P5Arr {

	public static void main(String[] args) {
		
		Scanner hmm = new Scanner(System.in);
		int search, count=0;
		search = hmm.nextInt();
		int array[] = {7, 13, 2, 10, 6};
		
		for (int i = 0; i < array.length; i++) {
			if (array[i] == search) {
				System.out.println(search + " was found.");
				count=1;
				break;
				
			}
		}
		if (count==0) {
			System.out.println(search + " was not found.");
		}
		
		System.out.println();

	}

}
