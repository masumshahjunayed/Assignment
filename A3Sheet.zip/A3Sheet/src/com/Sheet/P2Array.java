package com.Sheet;

import java.util.Arrays;

public class P2Array {

	public static void main(String[] args) {
		
		int[] myarray = {7, 13, 2, 10, 6};
		
		Arrays.sort(myarray);
		System.out.println(Arrays.toString(myarray));

	}

}
